####################################

Certificates_PKCS7_v5.0u1_DoD

####################################

File Information:


Certificates_PKCS7_v5.0u1_DoD.der.p7b: Contains Roots 'DoD Root CA 2', 'DoD Root CA 3', 'DoD Root CA 4' and 36 CA certificates, PKCS7 DER encoded. Ideal for Windows OSes.
Certificates_PKCS7_v5.0u1_DoD.pem.p7b: Contains Roots 'DoD Root CA 2', 'DoD Root CA 3', 'DoD Root CA 4' and 36 CA certificates, PKCS7 PEM encoded. Ideal for Linux or Windows OSes.
Certificates_PKCS7_v5.0u1_DoD_DoDRootCA2_withCAs_FirefoxChromeOS.der.p7b: Contains Root 'DoD Root CA 2' and 22 CA certificates, PKCS7 DER encoded. Ideal for Firefox and ChromeOS.
Certificates_PKCS7_v5.0u1_DoD_DoDRootCA3_withCAs_FirefoxChromeOS.der.p7b: Contains Root 'DoD Root CA 3' and 12 CA certificates, PKCS7 DER encoded. Ideal for Firefox and ChromeOS.
Certificates_PKCS7_v5.0u1_DoD_DoDRootCA4_withCAs_FirefoxChromeOS.der.p7b: Contains Root 'DoD Root CA 4' and 2 CA certificates, PKCS7 DER encoded. Ideal for Firefox and ChromeOS.
Certificates_PKCS7_v5.0u1_DoD_OSX_CAsOnly.der.p7b: Contains 36 CA certificates, PKCS7 DER encoded. Ideal for OS X.
DoD_PKE_CA_chain.pem: Signers chain for digital signatures on this package.
DoD_Root_CA_2__0x05__DoD_Root_CA_2.cer: Contains Root 'DoD Root CA 2', PEM encoded. Ideal for OS X.
DoD_Root_CA_3__0x01__DoD_Root_CA_3.cer: Contains Root 'DoD Root CA 3', PEM encoded. Ideal for OS X.
DoD_Root_CA_4__0x01__DoD_Root_CA_4.cer: Contains Root 'DoD Root CA 4', PEM encoded. Ideal for OS X.
README.txt: This file.


Verification:


To verify this PKCS#7 package please perform the following steps:


1)  Verify Thumbprint on the first DoD_PKE_CA_chain.pem certificate using the following command:
openssl x509 -in DoD_PKE_CA_chain.pem -subject -issuer -fingerprint -noout


Verify the following output:
subject=/C=US/O=U.S. Government/OU=DoD/OU=PKI/CN=DoD Root CA 2
issuer= /C=US/O=U.S. Government/OU=DoD/OU=PKI/CN=DoD Root CA 2
SHA1 Fingerprint=8C:94:1B:34:EA:1E:A6:ED:9A:E2:BC:54:CF:68:72:52:B4:C9:B5:61

Confirm output and verify the DoD Root CA 2 SHA1 Fingerprint by calling the DoD PKI at (844) 347-2457 or DSN 850-0032.


2) Open DoD_PKE_CA_chain.pem in a text editor and confirm only two CERTIFICATE objects are present.


3) Verify the S/MIME signature on Certificates_PKCS7_v5.0u1_DoD.sha256 using the following command:
openssl smime -verify -in Certificates_PKCS7_v5.0u1_DoD.sha256 -inform DER -CAfile DoD_PKE_CA_chain.pem | dos2unix | sha256sum -c

Verify the following output:
Verification successful
Certificates_PKCS7_v5.0u1_DoD.der.p7b: OK
Certificates_PKCS7_v5.0u1_DoD.pem.p7b: OK
Certificates_PKCS7_v5.0u1_DoD_DoDRootCA2_withCAs_FirefoxChromeOS.der.p7b: OK
Certificates_PKCS7_v5.0u1_DoD_DoDRootCA3_withCAs_FirefoxChromeOS.der.p7b: OK
Certificates_PKCS7_v5.0u1_DoD_DoDRootCA4_withCAs_FirefoxChromeOS.der.p7b: OK
Certificates_PKCS7_v5.0u1_DoD_OSX_CAsOnly.der.p7b: OK
DoD_Root_CA_2__0x05__DoD_Root_CA_2.cer: OK
DoD_Root_CA_3__0x01__DoD_Root_CA_3.cer: OK
DoD_Root_CA_4__0x01__DoD_Root_CA_4.cer: OK


####################################

Usage:


Openssl - To export CA certificates to a concatenated PEM file for use as an openssl CAfile (named e.g. DoD_CAs.pem), use the following command:
openssl pkcs7 -in Certificates_PKCS7_v5.0u1_DoD.pem.p7b -print_certs -out DoD_CAs.pem


Firefox 45.0 - To import certificates into the browser trust store:

1. Open the browser and select Firefox > Options > Advanced.  

2. Select the Certificates tab and click the View Certificates button.  

3. Select the Authorities tab and click Import...

4. In the file types drop-down, select All Files(*.*)

5. Browse to and select Certificates_PKCS7_v5.0u1_DoD.der.p7b
  Click Open.

6. Check all three boxes ("Trust this CA to identify websites", "Trust this CA to identify email users", and "Trust this CA to identify software developers") when prompted and click OK.

